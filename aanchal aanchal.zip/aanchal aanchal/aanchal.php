<?php
include 'contect.php';
if(isset($_POST ['submit'])){
  $name=$_POST['name'];
  $email=$_POST['email'];
  $phone=$_POST['phoneno'];
  $password=$_POST['password'];
  $sql="insert into crud(name,email,mobile,password)
  values('$name','$email','$phone','$password')";
  $result=mysqli_query($con,$sql);
  if($result)
  {
    header("location:display.php");
  }
  else{
    die(mysqli_error($con));
  }
}
?>

<html>
    <head> 
        <title>hello</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        
    </head>
<body>
<div class="container my-4"> 
<form method="post">
  <div class="form-group">
    <label>name</label>
    <input type="text" class="form-control" 
    placehoder="enter your name"
    name="name"autocomplete="off"></div>
    <div class="form-group">
    <label>email</label>
    <input type="email" class="form-control" 
    placehoder="enter your email"
    name="email"autocomplete="off"></div>
    <div class="form-group">
    <label>phonno</label>
    <input type="text" class="form-control" 
    placehoder="enter your phoneno"
    name="phoneno"autocomplete="off"></div>
    <div class="form-group">
    <label>password</label>
    <input type="text" class="form-control" 
    placehoder="enter your password"
    name="password"autocomplete="off"></div>
  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>
</div>
</body>
</html>