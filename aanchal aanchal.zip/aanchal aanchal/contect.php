<?php

$con= new mysqli('localhost','root','','aanchal');

if ($con){
    echo"connection successfull";
}else{
    die (mysqli_error($con));
}

?>